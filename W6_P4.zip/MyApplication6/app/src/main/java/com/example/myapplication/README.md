bann.png contains the picture for the animations

anim1.xml contains the instructions for the first animation

anim2.xml contains the instructions fr the second animation

Main activity implements the animations using a listener